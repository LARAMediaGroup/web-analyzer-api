<?php
/**
 * Web Analyzer API Fix
 * 
 * This file helps fix the REST API issue for the Web Analyzer plugin.
 * Upload this file to your WordPress wp-content/plugins/ directory
 * and access it via browser to apply the fix.
 */

// Load WordPress
define('WP_USE_THEMES', false);
require_once('../../wp-load.php');

// Security check
if (!current_user_can('administrator')) {
    die('You must be an administrator to access this page.');
}

echo '<h1>Web Analyzer API Fix</h1>';

// Check if plugin is active
if (!is_plugin_active('web-analyzer/web-analyzer.php')) {
    echo '<p style="color:red;">Error: Web Analyzer plugin is not active. Please activate it first.</p>';
    die();
}

// Get plugin instance
echo '<p>Loading plugin classes...</p>';
require_once(WP_PLUGIN_DIR . '/web-analyzer/includes/class-web-analyzer-loader.php');
require_once(WP_PLUGIN_DIR . '/web-analyzer/includes/class-web-analyzer-api.php');

// Create API instance and register routes
$plugin_api = new Web_Analyzer_API('web-analyzer', WEB_ANALYZER_VERSION);
$plugin_api->register_routes();

// Flush rewrite rules
echo '<p>Flushing rewrite rules...</p>';
flush_rewrite_rules();

// Test REST API route
echo '<h2>Testing REST API Route</h2>';
echo '<p>Testing REST API route registration...</p>';

$rest_server = rest_get_server();
$routes = $rest_server->get_routes();
$web_analyzer_routes = array_filter(array_keys($routes), function($route) {
    return strpos($route, 'web-analyzer') !== false;
});

if (count($web_analyzer_routes) > 0) {
    echo '<p style="color:green;">Success! Found the following Web Analyzer routes:</p>';
    echo '<ul>';
    foreach ($web_analyzer_routes as $route) {
        echo '<li>' . esc_html($route) . '</li>';
    }
    echo '</ul>';
} else {
    echo '<p style="color:red;">Error: No Web Analyzer routes were found.</p>';
}

// Add workaround for directly registering the route
echo '<h2>Applying Direct Fix</h2>';

// Register the route again on the next page load
update_option('web_analyzer_fix_applied', time());

// Add the hook for the fix
add_action('rest_api_init', function() {
    if (!class_exists('Web_Analyzer_API')) {
        require_once(WP_PLUGIN_DIR . '/web-analyzer/includes/class-web-analyzer-api.php');
    }
    
    $plugin_api = new Web_Analyzer_API('web-analyzer', WEB_ANALYZER_VERSION);
    $plugin_api->register_routes();
}, 20);

echo '<p style="color:green;">Fix applied successfully!</p>';
echo '<p>Please try the bulk processing again now. You may need to refresh your admin page first.</p>';

// Add a hook to run on next initialization
add_action('init', function() {
    add_action('rest_api_init', function() {
        if (!class_exists('Web_Analyzer_API')) {
            require_once(WP_PLUGIN_DIR . '/web-analyzer/includes/class-web-analyzer-api.php');
        }
        
        $plugin_api = new Web_Analyzer_API('web-analyzer', WEB_ANALYZER_VERSION);
        $plugin_api->register_routes();
    }, 20);
});

// Create a special hook for the admin
add_action('admin_notices', function() {
    echo '<div class="notice notice-success is-dismissible">';
    echo '<p>Web Analyzer API routes have been fixed. Please try running bulk processing now.</p>';
    echo '</div>';
});