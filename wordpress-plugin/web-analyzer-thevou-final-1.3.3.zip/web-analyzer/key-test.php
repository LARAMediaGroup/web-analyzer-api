<?php
/**
 * Simple API Key Test
 * This file tests each API key with both health and authenticated endpoints
 */

// Set timezone
date_default_timezone_set('UTC');

// Headers for plain text output
header('Content-Type: text/plain');

// All possible keys to test
$keys = [
    'Current Key' => 'j75x+z5imUKNHIyLk7zTNSTF/juUlwf4',
    'Previous Key' => 'u1HG8J0uUenblA7KJuUhVlTX',
    'URL Encoded Current Key' => urlencode('j75x+z5imUKNHIyLk7zTNSTF/juUlwf4'),
    'Without Special Chars' => 'j75xz5imUKNHIyLk7zTNSTFjuUlwf4',
];

// API info
$api_url = 'https://web-analyzer-api.onrender.com';
$site_id = 'thevou';

echo "WEB ANALYZER API KEY TEST\n";
echo "==============================\n\n";
echo "Date: " . date('Y-m-d H:i:s') . " UTC\n";
echo "API URL: {$api_url}\n";
echo "Site ID: {$site_id}\n\n";

// Test each key against both health and auth endpoints
foreach ($keys as $label => $key) {
    echo "TESTING: {$label} - {$key}\n";
    echo "------------------------------\n";
    
    // Test health endpoint (should work with any key)
    echo "1. Health Endpoint Test:\n";
    $health_response = wp_remote_get($api_url . '/health', [
        'timeout' => 15,
        'headers' => ['X-API-Key' => $key]
    ]);
    
    $health_code = wp_remote_retrieve_response_code($health_response);
    $health_body = wp_remote_retrieve_body($health_response);
    
    echo "   Status Code: {$health_code}\n";
    echo "   Response: {$health_body}\n\n";
    
    // Test bulk/jobs endpoint (requires valid auth)
    echo "2. Auth Endpoint Test (bulk/jobs):\n";
    $auth_response = wp_remote_get($api_url . '/bulk/jobs', [
        'timeout' => 15,
        'headers' => ['X-API-Key' => $key]
    ]);
    
    $auth_code = wp_remote_retrieve_response_code($auth_response);
    $auth_body = wp_remote_retrieve_body($auth_response);
    
    echo "   Status Code: {$auth_code}\n";
    echo "   Response: " . substr($auth_body, 0, 100) . (strlen($auth_body) > 100 ? "...\n" : "\n") . "\n";
    
    // Test content analysis endpoint
    echo "3. Content Analysis Test:\n";
    $test_data = [
        'content' => 'This is a test content.',
        'title' => 'Test Title',
        'site_id' => $site_id,
        'url' => 'https://example.com/test'
    ];
    
    $content_response = wp_remote_post($api_url . '/analyze/content', [
        'timeout' => 30,
        'headers' => [
            'X-API-Key' => $key,
            'Content-Type' => 'application/json'
        ],
        'body' => json_encode($test_data)
    ]);
    
    $content_code = wp_remote_retrieve_response_code($content_response);
    $content_body = wp_remote_retrieve_body($content_response);
    
    echo "   Status Code: {$content_code}\n";
    echo "   Response: " . substr($content_body, 0, 100) . (strlen($content_body) > 100 ? "...\n" : "\n") . "\n";
    
    echo "\n\n";
}

// Test new key
$site_id = 'thevou';
$key = 'p6fHDUXqGRgV4SNIXrxLG-Z01TVXVjtIk5ODiMmj6F8';
$response = test_key($key, $site_id);
echo "Testing key: $key for site: $site_id\n";
echo "Response: " . json_encode($response) . "\n\n";

// Direct curl test for comparison
echo "Direct curl test with command:\n";
echo "curl -X GET https://web-analyzer-api.onrender.com/health \\\n";
echo "-H 'X-API-Key: p6fHDUXqGRgV4SNIXrxLG-Z01TVXVjtIk5ODiMmj6F8'\n\n";

// Test direct debug of request
echo "SPECIAL TEST WITH CURL\n";
echo "==============================\n\n";

// Create a curl request to inspect headers
$ch = curl_init($api_url . '/bulk/jobs');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-Key: development_key_thevou'
]);
$response = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);

echo "CURL Request Headers:\n";
echo "X-API-Key: development_key_thevou\n\n";
echo "CURL Response Status: {$info['http_code']}\n";
echo "CURL Response Headers:\n";
$header_size = $info['header_size'];
$header = substr($response, 0, $header_size);
echo $header . "\n";

echo "\nTest completed at " . date('Y-m-d H:i:s') . " UTC\n";