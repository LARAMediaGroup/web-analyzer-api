<?php
/**
 * Web Analyzer Comprehensive Debug Tool
 * 
 * This standalone file performs extensive testing of the Web Analyzer API
 * and provides a detailed log that can be downloaded.
 */

// Security headers
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Set timezone
date_default_timezone_set('UTC');

// Output as HTML by default
header('Content-Type: text/html; charset=utf-8');

// Check if it's a download request
if (isset($_GET['download']) && $_GET['download'] === 'log') {
    // Output as a downloadable text file
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="web-analyzer-debug-' . date('Ymd-His') . '.log"');
}

// Start output buffering for the log
ob_start();

// Helper function for logging
function log_message($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    echo "[$timestamp] [$level] $message\n";
}

// Helper function to output a divider
function log_divider() {
    echo "\n" . str_repeat('-', 80) . "\n\n";
}

// Helper function to show response details
function log_response($response, $label = 'Response') {
    if (is_wp_error($response)) {
        log_message("$label ERROR: " . $response->get_error_message(), 'ERROR');
        return;
    }
    
    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    
    log_message("$label Status Code: $status_code");
    
    // Try to parse JSON response
    $parsed_body = json_decode($body, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        log_message("$label Body (JSON):");
        echo json_encode($parsed_body, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
    } else {
        // Plain text response
        log_message("$label Body (Text):");
        if (strlen($body) > 1000) {
            echo substr($body, 0, 1000) . "... [truncated]\n";
        } else {
            echo $body . "\n";
        }
    }
}

// Helper function to test an API endpoint with various keys
function test_endpoint($url, $method = 'GET', $data = null, $label = 'Endpoint Test') {
    global $all_keys;
    
    log_message("Testing $method $url");
    log_message("Test Label: $label");
    
    // Test with each API key
    foreach ($all_keys as $key_label => $api_key) {
        log_message("Trying with key: $key_label");
        
        $args = [
            'method' => $method,
            'timeout' => 30,
            'headers' => [
                'X-API-Key' => $api_key,
                'Content-Type' => 'application/json'
            ]
        ];
        
        if ($data && $method !== 'GET') {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        log_response($response, "$label ($key_label)");
        
        // Add a separator between key tests
        echo "\n";
    }
}

// Start the debugger
log_message("Starting Web Analyzer Debug Tool", 'START');
log_message("PHP Version: " . phpversion());
log_message("WordPress Version: " . get_bloginfo('version'));
log_message("Server: " . $_SERVER['SERVER_SOFTWARE']);
log_message("User Agent: " . $_SERVER['HTTP_USER_AGENT']);

log_divider();

// Get WordPress plugin settings
log_message("WordPress Plugin Settings:", 'CONFIG');
$wp_api_url = get_option('web_analyzer_api_url', '');
$wp_api_key = get_option('web_analyzer_api_key', '');
$wp_site_id = get_option('web_analyzer_site_id', '');

log_message("WordPress Option: web_analyzer_api_url = " . ($wp_api_url ? $wp_api_url : 'Not set'));
log_message("WordPress Option: web_analyzer_api_key = " . ($wp_api_key ? '[SET]' : 'Not set'));
log_message("WordPress Option: web_analyzer_site_id = " . ($wp_site_id ? $wp_site_id : 'Not set'));

log_divider();

// Define API credentials to test - try both old and new keys
$api_url = 'https://web-analyzer-api.onrender.com';
$site_id = 'thevou';

// Try all known and potentially valid keys
$all_keys = [
    'Recent Render Key' => 'j75x+z5imUKNHIyLk7zTNSTF/juUlwf4',
    'Previous Key' => 'u1HG8J0uUenblA7KJuUhVlTX',
    'WordPress Setting' => $wp_api_key,
    'Development Key' => 'development_key_only_for_testing',
    'Test Site Key' => 'testsite_key_for_development',
];

// Remove empty keys
foreach ($all_keys as $key => $value) {
    if (empty($value)) {
        unset($all_keys[$key]);
    }
}

// Log the test configuration
log_message("Debug Test Configuration:", 'CONFIG');
log_message("API URL: $api_url");
log_message("Site ID: $site_id");
log_message("Testing with " . count($all_keys) . " different API keys");

log_divider();

// TEST 1: Health check (should work without auth)
log_message("TEST 1: Health Check (No Auth Required)", 'TEST');
$health_url = $api_url . '/health';
$response = wp_remote_get($health_url, ['timeout' => 15]);
log_response($response, "Health Check");

log_divider();

// TEST 2: Authentication with different keys
log_message("TEST 2: API Authentication Test", 'TEST');
$auth_url = $api_url . '/bulk/jobs';
test_endpoint($auth_url, 'GET', null, 'Authentication Test');

log_divider();

// TEST 3: Site configuration tests
log_message("TEST 3: Site Configuration Test", 'TEST');

// Simple test content
$test_data = [
    'content' => 'This is a test content for debugging purposes.',
    'title' => 'API Debug Test',
    'site_id' => $site_id,
    'url' => site_url()
];

$analyze_url = $api_url . '/analyze/content';
test_endpoint($analyze_url, 'POST', $test_data, 'Content Analysis Test');

log_divider();

// TEST 4: Knowledge DB stats
log_message("TEST 4: Knowledge Database Stats", 'TEST');
$knowledge_url = $api_url . '/knowledge/stats';
test_endpoint($knowledge_url, 'GET', null, 'Knowledge DB Stats Test');

log_divider();

// TEST 5: Try analyze with 'default' site_id
log_message("TEST 5: Default Site ID Test", 'TEST');
$default_test_data = [
    'content' => 'This is a test content using default site ID.',
    'title' => 'Default Site Test',
    'site_id' => 'default',
    'url' => site_url()
];
test_endpoint($analyze_url, 'POST', $default_test_data, 'Default Site ID Test');

log_divider();

// TEST 6: Test without site_id parameter
log_message("TEST 6: No Site ID Test", 'TEST');
$no_site_test_data = [
    'content' => 'This is a test content without explicit site ID.',
    'title' => 'No Site ID Test',
    'url' => site_url()
];
test_endpoint($analyze_url, 'POST', $no_site_test_data, 'No Site ID Test');

log_divider();

// TEST 7: Check hardcoded values in the plugin
log_message("TEST 7: Plugin Hardcoded Values Check", 'CHECK');

// Try to include the plugin files to check hardcoded values
try {
    if (file_exists(__DIR__ . '/includes/class-web-analyzer-api.php')) {
        $api_file_content = file_get_contents(__DIR__ . '/includes/class-web-analyzer-api.php');
        preg_match_all('/\$api_key\s*=\s*[\'"]([^\'"]+)[\'"]/', $api_file_content, $matches);
        
        if (!empty($matches[1])) {
            log_message("Found hardcoded API keys in class-web-analyzer-api.php:");
            foreach (array_unique($matches[1]) as $key) {
                log_message("- $key");
                
                // Check if it's in our test set
                $found = false;
                foreach ($all_keys as $label => $value) {
                    if ($value === $key) {
                        $found = true;
                        log_message("  (This matches the '$label' key)");
                        break;
                    }
                }
                
                if (!$found) {
                    log_message("  WARNING: This key is not in our test set!", 'WARNING');
                    // Add it to our keys for testing
                    $all_keys['API Class Key'] = $key;
                }
            }
        } else {
            log_message("No API keys found in class-web-analyzer-api.php", 'WARNING');
        }
        
        preg_match_all('/\$site_id\s*=\s*[\'"]([^\'"]+)[\'"]/', $api_file_content, $matches);
        if (!empty($matches[1])) {
            log_message("Found hardcoded site IDs in class-web-analyzer-api.php:");
            foreach (array_unique($matches[1]) as $id) {
                log_message("- $id");
                
                if ($id !== $site_id) {
                    log_message("  WARNING: This doesn't match our test site ID '$site_id'!", 'WARNING');
                }
            }
        } else {
            log_message("No site IDs found in class-web-analyzer-api.php", 'WARNING');
        }
    } else {
        log_message("Cannot find class-web-analyzer-api.php file", 'WARNING');
    }
    
    // Check JS files
    if (file_exists(__DIR__ . '/admin/js/web-analyzer-direct-api.js')) {
        $js_file_content = file_get_contents(__DIR__ . '/admin/js/web-analyzer-direct-api.js');
        preg_match_all('/apiKey\s*=\s*[\'"]([^\'"]+)[\'"]/', $js_file_content, $matches);
        
        if (!empty($matches[1])) {
            log_message("Found hardcoded API keys in web-analyzer-direct-api.js:");
            foreach (array_unique($matches[1]) as $key) {
                log_message("- $key");
                
                // Check if it's in our test set
                $found = false;
                foreach ($all_keys as $label => $value) {
                    if ($value === $key) {
                        $found = true;
                        log_message("  (This matches the '$label' key)");
                        break;
                    }
                }
                
                if (!$found) {
                    log_message("  WARNING: This key is not in our test set!", 'WARNING');
                    // Add it to our keys for testing
                    $all_keys['JS File Key'] = $key;
                }
            }
        } else {
            log_message("No API keys found in web-analyzer-direct-api.js", 'WARNING');
        }
    } else {
        log_message("Cannot find web-analyzer-direct-api.js file", 'WARNING');
    }
    
    // Test any additional keys we found
    if (count($all_keys) > 5) {
        log_message("\nTesting additional keys found in the codebase:", 'TEST');
        $analyze_url = $api_url . '/analyze/content';
        test_endpoint($analyze_url, 'POST', $test_data, 'Additional Keys Test');
    }
    
} catch (Exception $e) {
    log_message("Error checking plugin files: " . $e->getMessage(), 'ERROR');
}

log_divider();

// Conclusion
log_message("Debug Tool Execution Complete", 'END');
log_message("Generated at: " . date('Y-m-d H:i:s') . " UTC");

// Get the full log content
$log_content = ob_get_clean();

// If this is a download request, output the log directly
if (isset($_GET['download']) && $_GET['download'] === 'log') {
    echo $log_content;
    exit;
}

// Otherwise display HTML page with the log
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Analyzer Comprehensive Debug Tool</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
            color: #333;
        }
        h1, h2 {
            color: #1e73be;
        }
        .debug-header {
            background: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .debug-actions {
            background: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        .debug-log {
            background: #282c34;
            color: #abb2bf;
            font-family: monospace;
            padding: 20px;
            border-radius: 4px;
            white-space: pre-wrap;
            overflow-x: auto;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            height: 600px;
            overflow-y: auto;
        }
        button, .button {
            background: #1e73be;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
        }
        button:hover, .button:hover {
            background: #135e9e;
        }
        .info {
            color: #6196cc;
        }
        .error {
            color: #e06c75;
        }
        .warning {
            color: #e5c07b;
        }
        .success {
            color: #98c379;
        }
        .highlight {
            color: #d19a66;
        }
    </style>
</head>
<body>
    <div class="debug-header">
        <h1>Web Analyzer Comprehensive Debug Tool</h1>
        <p>This tool performs extensive testing of the Web Analyzer API and provides a detailed log of all results.</p>
    </div>
    
    <div class="debug-actions">
        <a href="?download=log" class="button">Download Debug Log</a>
        <button onclick="window.location.reload()">Run Tests Again</button>
        <button onclick="copyToClipboard()">Copy Log to Clipboard</button>
    </div>
    
    <div class="debug-log" id="debug-log">
<?php
    // Format the log with syntax highlighting
    $formatted_log = preg_replace(
        [
            '/\[([\d\-\:\s]+)\]\s\[INFO\]/i',
            '/\[([\d\-\:\s]+)\]\s\[ERROR\]/i',
            '/\[([\d\-\:\s]+)\]\s\[WARNING\]/i',
            '/\[([\d\-\:\s]+)\]\s\[START\]/i',
            '/\[([\d\-\:\s]+)\]\s\[END\]/i',
            '/\[([\d\-\:\s]+)\]\s\[TEST\]/i',
            '/\[([\d\-\:\s]+)\]\s\[CONFIG\]/i',
            '/\[([\d\-\:\s]+)\]\s\[CHECK\]/i',
            '/Status Code: (2\d\d)/',
            '/Status Code: (4\d\d|5\d\d)/',
            '/PASSED|SUCCESS|OK/i',
            '/FAILED|ERROR|NOT/i',
            '/WARNING/i',
            '/"([^"]+)"/'
        ],
        [
            '<span class="info">[$1] [INFO]</span>',
            '<span class="error">[$1] [ERROR]</span>',
            '<span class="warning">[$1] [WARNING]</span>',
            '<span class="success">[$1] [START]</span>',
            '<span class="success">[$1] [END]</span>',
            '<span class="highlight">[$1] [TEST]</span>',
            '<span class="highlight">[$1] [CONFIG]</span>',
            '<span class="highlight">[$1] [CHECK]</span>',
            'Status Code: <span class="success">$1</span>',
            'Status Code: <span class="error">$1</span>',
            '<span class="success">$0</span>',
            '<span class="error">$0</span>',
            '<span class="warning">$0</span>',
            '"<span class="highlight">$1</span>"'
        ],
        $log_content
    );
    
    echo $formatted_log;
?>
    </div>
    
    <script>
        // Scroll to bottom of log by default
        document.addEventListener('DOMContentLoaded', function() {
            var logElement = document.getElementById('debug-log');
            logElement.scrollTop = logElement.scrollHeight;
        });
        
        // Function to copy log to clipboard
        function copyToClipboard() {
            var logElement = document.getElementById('debug-log');
            var textToCopy = logElement.innerText || logElement.textContent;
            
            navigator.clipboard.writeText(textToCopy).then(function() {
                alert('Debug log copied to clipboard!');
            }, function(err) {
                alert('Could not copy text: ' + err);
            });
        }
    </script>
</body>
</html>