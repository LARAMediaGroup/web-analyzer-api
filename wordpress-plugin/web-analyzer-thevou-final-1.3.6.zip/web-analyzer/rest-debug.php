<?php
/**
 * Debug file for Web Analyzer REST API routes
 * Copy this file to your WordPress root directory and access it via browser
 */

// Load WordPress
define('WP_USE_THEMES', false);
require_once('wp-load.php');

// Check if WordPress is loaded
if (!function_exists('add_action')) {
    die('WordPress not loaded');
}

echo '<h1>Web Analyzer REST API Debug</h1>';

// Check if the plugin is active
echo '<h2>Plugin Status</h2>';
if (is_plugin_active('web-analyzer/web-analyzer.php')) {
    echo '<p style="color:green;">Plugin is active</p>';
} else {
    echo '<p style="color:red;">Plugin is NOT active</p>';
}

// Check REST API availability
echo '<h2>WordPress REST API Status</h2>';
$wp_rest_server = rest_get_server();
if ($wp_rest_server) {
    echo '<p style="color:green;">WordPress REST API is available</p>';
} else {
    echo '<p style="color:red;">WordPress REST API is NOT available</p>';
}

// List all registered routes
echo '<h2>Registered REST Routes</h2>';
$routes = $wp_rest_server->get_routes();
echo '<ul>';
foreach ($routes as $route => $handlers) {
    if (strpos($route, 'web-analyzer') !== false) {
        echo '<li style="color:blue;"><strong>' . esc_html($route) . '</strong>';
        echo '<ul>';
        foreach ($handlers as $handler) {
            $methods = implode(', ', $handler['methods']);
            echo '<li>Methods: ' . esc_html($methods) . '</li>';
        }
        echo '</ul>';
        echo '</li>';
    }
}
echo '</ul>';

// Check hook registration for Web Analyzer
echo '<h2>Plugin Hooks Check</h2>';
global $wp_filter;
$rest_init_hooks = isset($wp_filter['rest_api_init']) ? $wp_filter['rest_api_init'] : array();

$found_api_hooks = false;
if (!empty($rest_init_hooks)) {
    foreach ($rest_init_hooks as $priority => $callbacks) {
        foreach ($callbacks as $callback) {
            if (is_array($callback['function']) && 
                is_object($callback['function'][0]) && 
                get_class($callback['function'][0]) === 'Web_Analyzer_API') {
                echo '<p style="color:green;">Found Web_Analyzer_API::register_routes hook on rest_api_init</p>';
                $found_api_hooks = true;
            }
        }
    }
}

if (!$found_api_hooks) {
    echo '<p style="color:red;">No Web_Analyzer_API hooks found on rest_api_init!</p>';
    
    // Check if hook is registered elsewhere
    echo '<h3>Looking for registration function in other hooks...</h3>';
    $register_routes_found = false;
    foreach ($wp_filter as $hook_name => $hook_callbacks) {
        foreach ($hook_callbacks as $priority => $callbacks) {
            foreach ($callbacks as $callback) {
                if (is_array($callback['function']) && 
                    is_object($callback['function'][0]) && 
                    get_class($callback['function'][0]) === 'Web_Analyzer_API' &&
                    $callback['function'][1] === 'register_routes') {
                    echo '<p>Found register_routes on hook: ' . esc_html($hook_name) . '</p>';
                    $register_routes_found = true;
                }
            }
        }
    }
    
    if (!$register_routes_found) {
        echo '<p>Did not find register_routes method registered to any hook.</p>';
    }
}

// Show plugin details
echo '<h2>Plugin Details</h2>';
$plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/web-analyzer/web-analyzer.php');
echo '<p><strong>Name:</strong> ' . esc_html($plugin_data['Name']) . '</p>';
echo '<p><strong>Version:</strong> ' . esc_html($plugin_data['Version']) . '</p>';
echo '<p><strong>Plugin URI:</strong> ' . esc_html($plugin_data['PluginURI']) . '</p>';
echo '<p><strong>Description:</strong> ' . esc_html($plugin_data['Description']) . '</p>';