<?php
/**
 * Admin area display for the plugin.
 *
 * @link       https://laramediagroup.com
 * @since      1.0.0
 * @package    Web_Analyzer
 * @subpackage Web_Analyzer/admin/partials
 */
?>

<div class="wrap web-analyzer-admin">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php settings_errors(); ?>
    
    <div class="web-analyzer-tabs">
        <nav class="nav-tab-wrapper">
            <a href="#settings" class="nav-tab nav-tab-active">Settings</a>
            <a href="#bulk-processing" class="nav-tab">Bulk Processing</a>
            <a href="#simple-debug" class="nav-tab">Simplified Debug Tool</a>
        </nav>
        
        <div id="settings" class="tab-content active">
            <form method="post" action="options.php" class="web-analyzer-settings-form">
                <?php
                settings_fields($this->plugin_name);
                do_settings_sections($this->plugin_name);
                ?>
                
                <h2>API Configuration</h2>
                <p>Configure the connection to the Web Analyzer API.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_api_url">API URL</label>
                        </th>
                        <td>
                            <input type="url" name="web_analyzer_api_url" id="web_analyzer_api_url" class="regular-text"
                                   placeholder="https://web-analyzer-api.onrender.com" 
                                   value="<?php echo esc_attr(get_option('web_analyzer_api_url')); ?>" />
                            <p class="description">The base URL for the Web Analyzer API.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_api_key">API Key</label>
                        </th>
                        <td>
                            <input type="password" name="web_analyzer_api_key" id="web_analyzer_api_key" class="regular-text"
                                   placeholder="Your API key" 
                                   value="<?php echo esc_attr(get_option('web_analyzer_api_key')); ?>" />
                            <p class="description">Your API key for authentication.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_site_id">Site ID</label>
                        </th>
                        <td>
                            <input type="text" name="web_analyzer_site_id" id="web_analyzer_site_id" class="regular-text"
                                   placeholder="thevou" 
                                   value="<?php echo esc_attr(get_option('web_analyzer_site_id')); ?>" />
                            <p class="description">Your site identifier.</p>
                        </td>
                    </tr>
                </table>
                
                <div class="api-notice">
                    <p><strong>Note:</strong> The plugin is currently configured with hardcoded credentials for TheVou in the plugin code files. The settings above may be ignored in favor of hardcoded values.</p>
                    <p>For reliable authentication testing, please use the <a href="<?php echo esc_url(plugins_url('/one-button-debug.php', dirname(dirname(__FILE__)))); ?>">Simplified Debug Tool</a>.</p>
                </div>
                
                <h2>Analysis Settings</h2>
                <p>Configure how content is analyzed.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_enabled">Enable Analysis</label>
                        </th>
                        <td>
                            <input type="checkbox" name="web_analyzer_enabled" id="web_analyzer_enabled" 
                                  <?php checked(get_option('web_analyzer_enabled', true), true); ?> value="1" />
                            <span class="description">Enable or disable content analysis.</span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_max_suggestions">Maximum Suggestions</label>
                        </th>
                        <td>
                            <input type="number" name="web_analyzer_max_suggestions" id="web_analyzer_max_suggestions" class="small-text"
                                   min="1" max="50" 
                                   value="<?php echo esc_attr(get_option('web_analyzer_max_suggestions', 10)); ?>" />
                            <p class="description">Maximum number of link suggestions to display.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_use_enhanced">Use Enhanced Analysis</label>
                        </th>
                        <td>
                            <input type="checkbox" name="web_analyzer_use_enhanced" id="web_analyzer_use_enhanced" 
                                  <?php checked(get_option('web_analyzer_use_enhanced', false), true); ?> value="1" />
                            <span class="description">Use enhanced analysis for better link suggestions (may be slower).</span>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Save Settings'); ?>
            </form>
        </div>
        
        <div id="bulk-processing" class="tab-content">
            <h2>Bulk Content Processing</h2>
            <p>Process multiple posts at once for link suggestions or to build the knowledge database.</p>
            
            <div class="bulk-settings">
                <h3>Bulk Processing Settings</h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_bulk_post_type">Post Type</label>
                        </th>
                        <td>
                            <select id="web_analyzer_bulk_post_type" name="web_analyzer_bulk_post_type">
                                <option value="post" <?php selected(get_option('web_analyzer_bulk_post_type', 'post'), 'post'); ?>>Posts</option>
                                <option value="page" <?php selected(get_option('web_analyzer_bulk_post_type', 'post'), 'page'); ?>>Pages</option>
                            </select>
                            <p class="description">The type of content to process.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_bulk_limit">Number of Items</label>
                        </th>
                        <td>
                            <input type="number" id="web_analyzer_bulk_limit" name="web_analyzer_bulk_limit" class="small-text"
                                   min="1" max="100" 
                                   value="<?php echo esc_attr(get_option('web_analyzer_bulk_limit', 10)); ?>" />
                            <p class="description">Number of content items to process (max 100).</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="web_analyzer_knowledge_mode">Processing Mode</label>
                        </th>
                        <td>
                            <select id="web_analyzer_knowledge_mode" name="web_analyzer_knowledge_mode">
                                <option value="build" <?php selected(get_option('web_analyzer_knowledge_mode', 'suggest'), 'build'); ?>>Knowledge Building Mode</option>
                                <option value="suggest" <?php selected(get_option('web_analyzer_knowledge_mode', 'suggest'), 'suggest'); ?>>Link Suggestion Mode</option>
                            </select>
                            <p class="description">Choose between building the knowledge database or generating link suggestions.</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button id="web-analyzer-start-bulk" class="button button-primary">Start Processing</button>
                </p>
            </div>
            
            <div id="web-analyzer-bulk-status" class="bulk-status" style="display:none;">
                <h3>Processing Status</h3>
                <div class="status-info">
                    <p><strong>Job Status:</strong> <span id="job-status-text">Starting...</span></p>
                    <p><strong>Mode:</strong> <span id="job-mode-text">Building Knowledge Database</span></p>
                    <p><strong>Progress:</strong> <span id="job-progress">0%</span></p>
                    <div class="progress-bar">
                        <div id="progress-bar-inner" style="width: 0%;"></div>
                    </div>
                    <p><strong>Items Processed:</strong> <span id="processed-count">0</span>/<span id="total-count">0</span></p>
                    <p><strong>Time Elapsed:</strong> <span id="time-elapsed">0s</span></p>
                </div>
            </div>
            
            <div class="knowledge-db-status">
                <h3>Knowledge Database Status</h3>
                <div id="knowledge-db-status">
                    <p><strong>Content Items:</strong> <span id="knowledge-content-count">-</span></p>
                    <p><strong>Ready for Analysis:</strong> <span id="knowledge-ready">-</span></p>
                    <p><strong>Minimum Required:</strong> <span id="knowledge-minimum">100</span></p>
                    <div class="progress-bar">
                        <div id="knowledge-progress-bar" style="width: 0%;"></div>
                    </div>
                </div>
                <p>The knowledge database needs at least 100 content items to start generating link suggestions.</p>
            </div>
        </div>
        
        <div id="simple-debug" class="tab-content">
            <h2>Simplified Debug Tool</h2>
            <p>Use our one-button debug tool to diagnose any API connection issues.</p>
            
            <div class="card" style="max-width: 800px; padding: 20px; margin-top: 20px;">
                <h3>One-Button Debug Tool</h3>
                <p>This tool will run a comprehensive test of the API connection with all possible credentials and generate a detailed log file.</p>
                
                <p>Click the button below to access the debug tool:</p>
                
                <a href="<?php echo esc_url(plugins_url('/one-button-debug.php', dirname(dirname(__FILE__)))); ?>" class="button button-primary" target="_blank" style="padding: 10px 20px; font-size: 16px; height: auto;">Open Debug Tool</a>
                
                <p style="margin-top: 20px;">
                    <strong>What the tool does:</strong>
                </p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li>Tests multiple API credentials against different endpoints</li>
                    <li>Checks which hardcoded values are in the plugin files</li>
                    <li>Verifies configuration and settings</li>
                    <li>Generates a detailed log file that you can share</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        // Tab functionality
        $('.web-analyzer-tabs .nav-tab').on('click', function(e) {
            e.preventDefault();
            
            // Get the target tab
            var target = $(this).attr('href');
            
            // Remove active class from all tabs
            $('.web-analyzer-tabs .nav-tab').removeClass('nav-tab-active');
            $('.web-analyzer-tabs .tab-content').removeClass('active');
            
            // Add active class to the clicked tab
            $(this).addClass('nav-tab-active');
            $(target).addClass('active');
        });
    });
</script>

<style>
    .web-analyzer-admin .tab-content {
        display: none;
        padding: 20px 0;
    }
    
    .web-analyzer-admin .tab-content.active {
        display: block;
    }
    
    .web-analyzer-admin .bulk-status {
        background: #f9f9f9;
        border: 1px solid #e5e5e5;
        padding: 15px;
        margin-top: 20px;
        border-radius: 4px;
    }
    
    .web-analyzer-admin .progress-bar {
        background: #e5e5e5;
        height: 20px;
        border-radius: 10px;
        margin: 10px 0;
        overflow: hidden;
    }
    
    .web-analyzer-admin .progress-bar div {
        background: #2271b1;
        height: 100%;
        transition: width 0.3s;
    }
    
    .web-analyzer-admin .knowledge-db-status {
        background: #f9f9f9;
        border: 1px solid #e5e5e5;
        padding: 15px;
        margin-top: 20px;
        border-radius: 4px;
    }
    
    .web-analyzer-admin .api-notice {
        background: #fff8e5;
        border-left: 4px solid #ffb900;
        padding: 10px 12px;
        margin: 20px 0;
    }
</style>