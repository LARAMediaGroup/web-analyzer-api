<?php
/**
 * Web Analyzer One-Button Debug Tool
 * 
 * This is a simplified tool with ONE button that performs a comprehensive test
 * and automatically downloads a detailed log file.
 */

// Set timezone
date_default_timezone_set('UTC');

// Check if test was requested
$is_test_requested = isset($_GET['run_test']);

// If test was requested, run the test and output as downloadable file
if ($is_test_requested) {
    // Set headers for download
    header('Content-Type: text/plain');
    header('Content-Disposition: attachment; filename="web-analyzer-debug-' . date('Ymd-His') . '.log"');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Run the tests and output log
    run_debug_tests();
    exit;
}

/**
 * Main function to run all debug tests
 */
function run_debug_tests() {
    log_message("Web Analyzer Debug Test - STARTED", 'START');
    log_message("Date/Time: " . date('Y-m-d H:i:s') . " UTC");
    log_message("PHP Version: " . phpversion());
    log_message("WordPress Version: " . get_bloginfo('version'));
    log_divider();
    
    // Test 1: Check plugin settings
    test_plugin_settings();
    log_divider();
    
    // Test 2: Check API health (no auth)
    test_api_health();
    log_divider();
    
    // Test 3: Test all API keys
    test_all_api_keys();
    log_divider();
    
    // Test 4: Check hardcoded values
    check_hardcoded_values();
    log_divider();
    
    log_message("Web Analyzer Debug Test - COMPLETED", 'END');
}

/**
 * Helper function to log a message
 */
function log_message($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    echo "[$timestamp] [$level] $message\n";
}

/**
 * Helper function to output a divider
 */
function log_divider() {
    echo "\n" . str_repeat('-', 80) . "\n\n";
}

/**
 * Helper function to log response details
 */
function log_response($response, $label = 'Response') {
    if (is_wp_error($response)) {
        log_message("$label ERROR: " . $response->get_error_message(), 'ERROR');
        return;
    }
    
    $status_code = wp_remote_retrieve_response_code($response);
    $body = wp_remote_retrieve_body($response);
    
    log_message("$label Status Code: $status_code");
    
    // Try to parse JSON response
    $parsed_body = json_decode($body, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        log_message("$label Body (JSON):");
        echo json_encode($parsed_body, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
    } else {
        // Plain text response
        log_message("$label Body (Text):");
        if (strlen($body) > 1000) {
            echo substr($body, 0, 1000) . "... [truncated]\n";
        } else {
            echo $body . "\n";
        }
    }
}

/**
 * Test WordPress plugin settings
 */
function test_plugin_settings() {
    log_message("TEST: WordPress Plugin Settings", 'TEST');
    
    $wp_api_url = get_option('web_analyzer_api_url', '');
    $wp_api_key = get_option('web_analyzer_api_key', '');
    $wp_site_id = get_option('web_analyzer_site_id', '');
    
    log_message("WordPress Option: web_analyzer_api_url = " . ($wp_api_url ? $wp_api_url : 'Not set'));
    log_message("WordPress Option: web_analyzer_api_key = " . ($wp_api_key ? '[SET]' : 'Not set'));
    log_message("WordPress Option: web_analyzer_site_id = " . ($wp_site_id ? $wp_site_id : 'Not set'));
}

/**
 * Test API health (no auth required)
 */
function test_api_health() {
    log_message("TEST: API Health Check (No Auth Required)", 'TEST');
    
    $api_url = 'https://web-analyzer-api.onrender.com';
    $health_url = $api_url . '/health';
    
    log_message("Testing endpoint: $health_url");
    $response = wp_remote_get($health_url, ['timeout' => 15]);
    log_response($response, "Health Check");
}

/**
 * Test all possible API keys
 */
function test_all_api_keys() {
    log_message("TEST: API Authentication with All Keys", 'TEST');
    
    $api_url = 'https://web-analyzer-api.onrender.com';
    $site_id = 'thevou';
    
    // Get WordPress plugin settings
    $wp_api_key = get_option('web_analyzer_api_key', '');
    
    // All possible keys to test
    $all_keys = [
        'Key 1 (Current Render)' => 'rnd_j4XBsK41N71qzDIy7Q7x7kFIyWLX',
        'Key 2 (Old Render)' => 'j75x+z5imUKNHIyLk7zTNSTF/juUlwf4',
        'Key 3 (Previous)' => 'u1HG8J0uUenblA7KJuUhVlTX',
        'Key 4 (WordPress Setting)' => $wp_api_key,
        'Key 5 (Development)' => 'development_key_only_for_testing',
    ];
    
    // Remove empty keys
    foreach ($all_keys as $label => $key) {
        if (empty($key)) {
            unset($all_keys[$label]);
        }
    }
    
    // Test each key with different endpoints
    foreach ($all_keys as $label => $api_key) {
        log_message("\nTesting $label: $api_key", 'KEY');
        
        // 1. Test auth endpoint
        log_message("AUTH TEST: Testing bulk jobs endpoint");
        $response = wp_remote_get(
            $api_url . '/bulk/jobs',
            [
                'timeout' => 15,
                'headers' => ['X-API-Key' => $api_key]
            ]
        );
        log_response($response, "Auth Test ($label)");
        
        // 2. Test content analysis
        log_message("CONTENT TEST: Testing analyze content endpoint");
        $test_data = [
            'content' => 'This is a test content for debugging.',
            'title' => 'Debug Test',
            'site_id' => $site_id,
            'url' => site_url()
        ];
        
        $response = wp_remote_post(
            $api_url . '/analyze/content',
            [
                'timeout' => 30,
                'headers' => [
                    'X-API-Key' => $api_key,
                    'Content-Type' => 'application/json'
                ],
                'body' => json_encode($test_data)
            ]
        );
        log_response($response, "Content Test ($label)");
        
        // 3. Test knowledge DB stats
        log_message("DB STATS TEST: Testing knowledge database stats");
        $response = wp_remote_get(
            $api_url . '/knowledge/stats',
            [
                'timeout' => 15,
                'headers' => ['X-API-Key' => $api_key]
            ]
        );
        log_response($response, "Knowledge DB Test ($label)");
    }
}

/**
 * Check hardcoded values in plugin files
 */
function check_hardcoded_values() {
    log_message("TEST: Hardcoded Values in Plugin Files", 'TEST');
    
    // Check API class file
    $api_file_path = __DIR__ . '/includes/class-web-analyzer-api.php';
    if (file_exists($api_file_path)) {
        log_message("Checking file: class-web-analyzer-api.php");
        $api_file_content = file_get_contents($api_file_path);
        
        // Extract API keys
        preg_match_all('/\$api_key\s*=\s*[\'"]([^\'"]+)[\'"]/', $api_file_content, $key_matches);
        if (!empty($key_matches[1])) {
            log_message("Found API keys in PHP file:");
            foreach (array_unique($key_matches[1]) as $key) {
                log_message("- $key");
            }
        } else {
            log_message("No API keys found in PHP file", 'WARNING');
        }
        
        // Extract site IDs
        preg_match_all('/\$site_id\s*=\s*[\'"]([^\'"]+)[\'"]/', $api_file_content, $id_matches);
        if (!empty($id_matches[1])) {
            log_message("Found site IDs in PHP file:");
            foreach (array_unique($id_matches[1]) as $id) {
                log_message("- $id");
            }
        } else {
            log_message("No site IDs found in PHP file", 'WARNING');
        }
    } else {
        log_message("Cannot find class-web-analyzer-api.php file", 'WARNING');
    }
    
    // Check JS file
    $js_file_path = __DIR__ . '/admin/js/web-analyzer-direct-api.js';
    if (file_exists($js_file_path)) {
        log_message("Checking file: web-analyzer-direct-api.js");
        $js_file_content = file_get_contents($js_file_path);
        
        // Extract API keys
        preg_match_all('/apiKey\s*=\s*[\'"]([^\'"]+)[\'"]/', $js_file_content, $key_matches);
        if (!empty($key_matches[1])) {
            log_message("Found API keys in JS file:");
            foreach (array_unique($key_matches[1]) as $key) {
                log_message("- $key");
            }
        } else {
            log_message("No API keys found in JS file", 'WARNING');
        }
        
        // Extract site IDs
        preg_match_all('/siteId\s*=\s*[\'"]([^\'"]+)[\'"]/', $js_file_content, $id_matches);
        if (!empty($id_matches[1])) {
            log_message("Found site IDs in JS file:");
            foreach (array_unique($id_matches[1]) as $id) {
                log_message("- $id");
            }
        } else {
            log_message("No site IDs found in JS file", 'WARNING');
        }
    } else {
        log_message("Cannot find web-analyzer-direct-api.js file", 'WARNING');
    }
    
    // Check direct API file
    $direct_api_path = __DIR__ . '/direct-api.php';
    if (file_exists($direct_api_path)) {
        log_message("Checking file: direct-api.php");
        $direct_api_content = file_get_contents($direct_api_path);
        
        // Extract API keys
        preg_match_all('/\$api_key\s*=\s*[\'"]([^\'"]+)[\'"]/', $direct_api_content, $key_matches);
        if (!empty($key_matches[1])) {
            log_message("Found API keys in direct-api.php:");
            foreach (array_unique($key_matches[1]) as $key) {
                log_message("- $key");
            }
        } else {
            log_message("No API keys found in direct-api.php", 'WARNING');
        }
    } else {
        log_message("Cannot find direct-api.php file", 'WARNING');
    }
}

// Output the HTML interface if this is a normal page view
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Analyzer - One-Button Debug Tool (v2.0.0)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f5f5f5;
            padding: 50px 20px;
            color: #333;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #1e73be;
            margin-bottom: 30px;
        }
        .big-button {
            background-color: #1e73be;
            color: white;
            border: none;
            border-radius: 30px;
            padding: 20px 40px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .big-button:hover {
            background-color: #135e9e;
            transform: scale(1.05);
        }
        .big-button:active {
            transform: scale(0.98);
        }
        .description {
            margin: 30px 0;
            line-height: 1.6;
            font-size: 16px;
        }
        .version {
            margin-top: 40px;
            color: #999;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Web Analyzer Debug Tool</h1>
        <p class="description">
            Click the button below to run a comprehensive diagnostic test.
            A log file will be automatically downloaded with detailed results.
        </p>
        
        <a href="?run_test=1" class="big-button">RUN DIAGNOSTIC TEST</a>
        
        <p class="version">Version 2.0.0</p>
    </div>
</body>
</html>